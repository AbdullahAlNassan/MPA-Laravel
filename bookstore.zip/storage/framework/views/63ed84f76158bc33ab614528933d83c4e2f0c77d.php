


<?php $__env->startSection('title', 'Genres'); ?>

<?php $__env->startSection('content'); ?>
  <h2>Genres</h2>

  <?php if($genres->count() >= 5): ?>
    <ul>
      <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          
          <a href="<?php echo e(url('/books')); ?>?genre=<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></a>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  <?php else: ?>
    <p>Voeg eerst meer genres toe via je seeder.</p>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/genres/index.blade.php ENDPATH**/ ?>