

<?php $__env->startSection('title', 'Nieuw boek'); ?>

<?php $__env->startSection('content'); ?>
  <h2>Nieuw boek</h2>

  <form method="POST" action="<?php echo e(route('books.store')); ?>" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo $__env->make('books._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <button type="submit">Opslaan</button>
      <a href="<?php echo e(route('books.index')); ?>">Annuleren</a>
  </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/books/create.blade.php ENDPATH**/ ?>