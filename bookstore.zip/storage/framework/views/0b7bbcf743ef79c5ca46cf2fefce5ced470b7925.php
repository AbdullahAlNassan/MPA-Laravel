

<?php $__env->startSection('title', 'Boek bewerken'); ?>

<?php $__env->startSection('content'); ?>
  <h2>Boek bewerken</h2>

  <form method="POST" action="<?php echo e(route('books.update', $book)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <?php echo $__env->make('books._form', ['book' => $book], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button type="submit">Opslaan</button>
    <a href="<?php echo e(route('books.show', $book)); ?>">Annuleren</a>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/books/edit.blade.php ENDPATH**/ ?>