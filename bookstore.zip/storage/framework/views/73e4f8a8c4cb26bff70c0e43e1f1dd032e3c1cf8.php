<!DOCTYPE html>
<html>
<head>
    <title>Contact</title>
</head>
<body>
    

    <?php $__env->startSection('title', 'Contact'); ?>

    <?php $__env->startSection('content'); ?>
        <h2>Contactpagina</h2>
        <p>Neem gerust contact met ons op. (Straks kun je hier een formulier maken.)</p>
    <?php $__env->stopSection(); ?>

</body>
</html>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/contact.blade.php ENDPATH**/ ?>