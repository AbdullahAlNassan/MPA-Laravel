
<?php $__env->startSection('title', 'Boeken'); ?>

<?php $__env->startSection('content'); ?>
  <div class="card" style="margin-bottom:1rem;">
    <form method="GET" action="<?php echo e(url('/books')); ?>" style="display:flex; gap:.5rem; flex-wrap:wrap; align-items:flex-end;">
      <div>
        <label for="q">Zoek</label><br>
        <input id="q" type="text" name="q" value="<?php echo e($q); ?>" placeholder="Titel of auteur">
      </div>
      <div>
        <label for="author">Auteur</label><br>
        <input id="author" type="text" name="author" value="<?php echo e($author); ?>">
      </div>
      <div>
        <label for="year_min">Jaar vanaf</label><br>
        <input id="year_min" type="number" name="year_min" value="<?php echo e($minYr); ?>">
      </div>
      <div>
        <label for="year_max">Jaar t/m</label><br>
        <input id="year_max" type="number" name="year_max" value="<?php echo e($maxYr); ?>">
      </div>
      <?php if(isset($genres)): ?>
      <div>
        <label for="genre">Genre</label><br>
        <select id="genre" name="genre">
          <option value="">— Alle genres —</option>
          <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($g->id); ?>" <?php echo e((string)$genre === (string)$g->id ? 'selected' : ''); ?>>
              <?php echo e($g->name); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <?php endif; ?>
      <div>
        <button type="submit">Filter</button>
        <a class="btn btn-ghost" href="<?php echo e(url('/books')); ?>">Reset</a>
        <a class="btn btn-secondary" href="<?php echo e(route('books.create')); ?>">+ Nieuw boek</a>
      </div>
    </form>
  </div>

  <?php if($books->count()): ?>
    <div class="grid">
      <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $cover = $book->cover_path
            ? asset('storage/'.$book->cover_path)
            : ($book->cover_url ?: 'https://via.placeholder.com/480x680?text=Book');
        ?>
        <article class="card">
          <img class="card-cover"
               src="<?php echo e($cover); ?>"
               alt="Cover van <?php echo e($book->title); ?>">
          <div class="card-body">
            <h3 class="card-title">
              <a href="<?php echo e(route('books.show', $book)); ?>"><?php echo e($book->title); ?></a>
            </h3>
            <p class="card-meta"><?php echo e($book->author); ?></p>
            <p class="card-meta">
              <?php if($book->published_year): ?> <?php echo e($book->published_year); ?> • <?php endif; ?>
              <?php if($book->pages): ?> <?php echo e($book->pages); ?> pag. <?php endif; ?>
            </p>
            <div class="card-actions">
              <a class="btn btn-ghost" href="<?php echo e(route('books.show', $book)); ?>">Bekijken</a>
              <a class="btn btn-secondary" href="<?php echo e(route('books.edit', $book)); ?>">Bewerken</a>
              <form method="POST" action="<?php echo e(route('books.destroy', $book)); ?>"
                    onsubmit="return confirm('Verwijderen?');" style="display:inline">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit">Verwijderen</button>
              </form>
            </div>
          </div>
        </article>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div style="margin-top:1rem;">
      <?php echo e($books->links()); ?>

    </div>
  <?php else: ?>
    <div class="card"><p>Geen boeken gevonden.</p></div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/books/index.blade.php ENDPATH**/ ?>