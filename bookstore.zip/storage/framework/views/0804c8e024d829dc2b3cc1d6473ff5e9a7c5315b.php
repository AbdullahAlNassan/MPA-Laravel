<!DOCTYPE html>
<html>
<head>
    <title>Over ons</title>
</head>
<body>

    

    <?php $__env->startSection('title', 'Over ons'); ?>

    <?php $__env->startSection('content'); ?>
        <h2>Over deze app</h2>
        <p>Hier kun je straks alles vertellen over de jukebox webapplicatie!</p>
    <?php $__env->stopSection(); ?>

</body>
</html>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/about.blade.php ENDPATH**/ ?>