

<?php $__env->startSection('title', $book->title); ?>

<?php $__env->startSection('content'); ?>
  <?php
    $cover = $book->cover_path
      ? asset('storage/'.$book->cover_path)
      : ($book->cover_url ?: 'https://via.placeholder.com/960x1360?text=Book');
  ?>
  <div class="card" style="max-width:900px; margin:0 auto;">
    <img class="card-cover" src="<?php echo e($cover); ?>"
         alt="Cover van <?php echo e($book->title); ?>">
    <div class="card-body">
      <a class="btn btn-ghost" href="<?php echo e(route('books.index')); ?>">&larr; Terug</a>
      <h2 class="card-title" style="margin-top:.5rem;"><?php echo e($book->title); ?></h2>
      <p class="card-meta"><strong>Auteur:</strong> <?php echo e($book->author); ?></p>
      <p class="card-meta"><strong>Jaar:</strong> <?php echo e($book->published_year ?? '—'); ?></p>
      <p class="card-meta"><strong>Pagina's:</strong> <?php echo e($book->pages ?? '—'); ?></p>

      <div class="card-actions">
        <a class="btn btn-secondary" href="<?php echo e(route('books.edit', $book)); ?>">Bewerken</a>
        <form method="POST" action="<?php echo e(route('books.destroy', $book)); ?>"
              onsubmit="return confirm('Verwijderen?');" style="display:inline">
          <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <button type="submit">Verwijderen</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/books/show.blade.php ENDPATH**/ ?>