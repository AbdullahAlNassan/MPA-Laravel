<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Jukebox'); ?></title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/layout.css')); ?>?v=<?php echo e(filemtime(public_path('css/layout.css'))); ?>">


</head>

<body>
    <header>
        <div class="container brand">
            <h1>Abdullah Books</h1>
            <nav class="nav">
                <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'is-active' : ''); ?>">Home</a>
                <a href="<?php echo e(route('about')); ?>" class="<?php echo e(request()->routeIs('about') ? 'is-active' : ''); ?>">Over ons</a>
                <a href="<?php echo e(route('contact')); ?>"
                    class="<?php echo e(request()->routeIs('contact') ? 'is-active' : ''); ?>">Contact</a>
                <a href="<?php echo e(route('books.index')); ?>"
                    class="<?php echo e(request()->routeIs('books.*') ? 'is-active' : ''); ?>">Boeken</a>
                <a href="<?php echo e(route('genres.index')); ?>"
                    class="<?php echo e(request()->routeIs('genres.*') ? 'is-active' : ''); ?>">Genres</a>
            </nav>
        </div>
    </header>
    <main>
        <div class="container">
            <?php if(session('status')): ?>
                <div class="alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
    <footer>
        <div class="container">
            &copy; <?php echo e(date('Y')); ?> Abdullah Books.
        </div>
    </footer>
</body>

</html><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/layout.blade.php ENDPATH**/ ?>