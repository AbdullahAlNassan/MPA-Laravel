<!DOCTYPE html>
<html>
<head>
    <title>Over ons</title>
</head>
<body>

    @extends('layout')

    @section('title', 'Over ons')

    @section('content')
        <h2>Over deze app</h2>
        <p>Hier kun je straks alles vertellen over de jukebox webapplicatie!</p>
    @endsection

</body>
</html>
