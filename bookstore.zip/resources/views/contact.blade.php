<!DOCTYPE html>
<html>
<head>
    <title>Contact</title>
</head>
<body>
    @extends('layout')

    @section('title', 'Contact')

    @section('content')
        <h2>Contactpagina</h2>
        <p>Neem gerust contact met ons op. (Straks kun je hier een formulier maken.)</p>
    @endsection

</body>
</html>
